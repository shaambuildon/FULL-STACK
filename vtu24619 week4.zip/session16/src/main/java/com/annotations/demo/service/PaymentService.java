package com.annotations.demo.service;

public interface PaymentService {
    String makePayment();
}