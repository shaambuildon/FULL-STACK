package com.annotations.demo.service;

public interface NotificationService {
    String sendNotification();
}