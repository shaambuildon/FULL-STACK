package com.annotations.demo.service;

import org.springframework.stereotype.Service;

@Service("smsService")
public class SMSNotificationService implements NotificationService {

    @Override
    public String sendNotification() {
        return "SMS notification sent";
    }
}