package com.annotations.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.annotations.demo.model.Employee;

@Controller   // ✅ VERY IMPORTANT
public class EmployeeMvcController {

    @GetMapping("/employee-mvc")
    public String showEmployee(Model model) {

        Employee emp = new Employee(101, "Shaam", "CSE");
        model.addAttribute("employee", emp);

        return "employee";   // view name (employee.html)
    }
}