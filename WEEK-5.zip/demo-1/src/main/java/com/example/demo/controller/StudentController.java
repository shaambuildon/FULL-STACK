package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class StudentController {

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @PostMapping("/submit")
    public String submitStudent(
            @RequestParam String name,
            @RequestParam String email) {

        System.out.println("Student Name: " + name);
        System.out.println("Student Email: " + email);

        return "success";
    }
}
